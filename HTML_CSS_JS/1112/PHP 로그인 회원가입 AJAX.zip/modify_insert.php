<meta charset="utf-8">
<?php
	include "dbpass.php";

	$id = $_POST['id'];
	$pw = $_POST['pw'];
	$name = $_POST['name'];

	$sql = "update member set pw='$pw', name='$name' where id='$id'";
	// member 테이블에서 id값이 일치하는 레코드 수정

	$result = $dbConnect->query($sql); // 데이터베이스 실행

	session_start();
	unset($_SESSION["userid"]); // unset 변수값 제거
?>
<script>
	alert('정보수정이 완료되었습니다 다시 로그인하시면 됩니다');
	location.href = 'index.php';
</script>
