<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>최용수 수업용</title>
	<script src="https://code.jquery.com/jquery-3.0.0.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
	
	<div id="member">
		<h2>회원가입</h2>
		<form method="post" action="member_insert.php">
			<ul>
				<li>
					<label for="id">아이디</label>
					<input type="text" id="id" name="id" placeholder="아이디를 입력해주세요." onBlur="idCheck()">
					<p class="id"></p>
				</li>
				<li>
					<label for="pw">비밀번호</label>
					<input type="password" id="pw" name="pw" placeholder="비밀번호" onBlur="pwCheck()">
					<p class="pw"></p>
				</li>
				<li>
					<label for="pw_confirm">비밀번호 확인</label>
					<input type="password" id="pw_confirm" placeholder="비밀번호 확인" onBlur="pw_confirmCheck()">
					<p class="pw_confirm"></p>
				</li>
				<li>
					<label for="name">이름</label>
					<input type="text" id="name" name="name" placeholder="이름을 입력해주세요." onBlur="nameCheck()">
					<p class="name"></p>
				</li>
			</ul>
			<hr>
			
			<button type="button" onClick="submitCheck(1)"><p>가입</p></button>
		</form>
	</div>
	
	<script>
		// 회원가입 정규표현식 변수
		var idReg = /^[a-zA-Z0-9]{2,20}$/;	// 아이디 정규표현식 (영문 및 숫자 2~20글자만 허용)
		var pwReg = /^(?=.*[a-zA-Z])((?=.*\d)|(?=.*\W))(?=.*[!@#$%^*+=-]).{3,20}$/	// 비밀번호 정규표현식 (특수문자가 1개 이상 포함된 영어, 숫자 조합의 3~20개의 글자
		var nameReg = /^[a-zA-Z가-힣]{2,20}$/;	// 이름 정규표현식 (한글 및 영문 2~20글자만 허용)
		var emailReg = /^[a-z0-9_+.-]+@([a-z0-9-]+\.)+[a-z0-9]{2,4}$/;	// 이메일 정규표현식
		
		$('#id').focus();
		
		function idCheck(){	// 아이디 검사
			$.ajax({
				type: "POST",
				url: "ajax.php",
				data: {
					a: $('#id').val(),
				}
			}).done(function(data){
				if(data != ""){
					$('p.id').text(data);
				} else if($('#id').val().length <= 0){
					$('p.id').text('아이디는 필수 사항입니다.');
				} else if(!idReg.test($('#id').val())){
					$('p.id').text('영문 및 숫자 2~20자만 허용');
				} else {
					$('p.id').text("");
				}
			})
		}
		
		function pwCheck(){	// 비밀번호 검사
			if($('#pw').val().length <= 0){
				$('p.pw').text('비밀번호를 작성해 주시기 바랍니다.');
			} else if(!pwReg.test($('#pw').val())){
				$('p.pw').text('3~20자 영문, 숫자, 특수문자를 사용하세요.');
			} else {
				$('p.pw').text("");
			}
		}
		
		function pw_confirmCheck(){	// 비밀번호 확인 검사
			if($('#pw_confirm').val().length <= 0){
				$('p.pw_confirm').text('비밀번호 확인을 위하여 다시 한번 작성해 주시기 바랍니다.');
			} else if($('#pw').val() != $('#pw_confirm').val()){
				$('p.pw_confirm').text('위 비밀번호와 같은 번호를 작성하여 주시기 바랍니다.');
			} else {
				$('p.pw_confirm').text("");
			}
		}
		
		function nameCheck(){	// 이름 검사
			if($('#name').val().length <= 0){
				$('p.name').text('이름은 필수 사항입니다.');
			} else if(!nameReg.test($('#name').val())){
				$('p.name').text('한글 및 영문 2~20자만 허용');
			} else {
				$('p.name').text("");
			}
		}
		
		function submitCheck(e){	// 가입버튼 클릭
			idCheck();
			pwCheck();
			pw_confirmCheck();
			nameCheck();
			
			for(var i = 0; i < 4; i++){
				if($('#member form ul li').eq(i).find('p').text() != ""){
					e = 0;
				}
			}
			
			if(e == 1){
				$('#member form').submit();
			}
		}
	</script>
	
</body>
</html>
