<?php
	include "dbpass.php";

	session_start();
    $userid = $_SESSION["userid"];

	$sql = "select * from member where id='$userid'";
    $result = $dbConnect->query($sql);
    $row = mysqli_fetch_array($result);

    $pw = $row["pw"];
    $name = $row["name"];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>회원정보수정</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="https://code.jquery.com/jquery-3.6.4.js"></script>
</head>

<body>
	<form id="form1" method="post" action="modify_insert.php">
		<p>아이디 : <?php echo $userid ?></p> <!--p태그에 입력된 값은 action파일로 전송 불가-->
		<input type="hidden" name="id" value="<?php echo $userid ?>">
		<input type="password" name="pw" value="<?php echo $pw ?>">
		<input type="text" name="name" value="<?php echo $name ?>">
		<button type="button">회원정보수정</button>
	</form>
	
	<form id="form2" method="post" action="modify_delete.php">
		<input type="hidden" name="id" value="<?php echo $userid ?>">
		<button type="button">회원탈퇴</button>
	</form>
	
	<script>
		$('#form1 button').click(function(){
			$('#form1').submit();	
		})
		
		$('#form2 button').click(function(){
			$('#form2').submit();	
		})
		
	</script>
</body>
</html>






