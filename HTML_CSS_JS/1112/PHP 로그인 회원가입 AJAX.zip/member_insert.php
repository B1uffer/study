<meta charset="utf-8">
<?php
	include "dbpass.php";

	$id = $_POST['id']; // [] 안에 name속성값을 넣음
	$pw = $_POST['pw']; // $ 변수선언
	$name = $_POST['name'];

	$sql = "insert into member(id, pw, name) values('$id', '$pw', '$name')";
	// insert into 테이블명(필드명) values(넣을값)
	// values() 안에 입력된 값을 comment테이블의 comment필드에 넣음
    $result = $dbConnect->query($sql);	// 데이터베이스 실행
?>
<script>
	alert('회원가입 완료');
	location.href = 'index.php';
</script>