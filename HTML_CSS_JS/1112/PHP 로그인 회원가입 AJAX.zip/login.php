<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>무제 문서</title>
	<script src="https://code.jquery.com/jquery-3.6.4.js"></script>
</head>

<body>
	<form method="post" action="login_insert.php">
		<input type="text" id="id" name="id">
		<input type="password" id="pw" name="pw">
		<button type="button">로그인</button>
	</form>
	
	<script>
		
		$('button').click(function(){
			
			if($('#id').val().length <= 0){
				alert('아이디를 입력하세요.');
			} else if($('#pw').val().length <= 0) {
				alert('비밀번호를 입력하세요.');
			} else {
				$('form').submit();	
			}
			
		})
		
	</script>
</body>
</html>




  
