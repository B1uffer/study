<meta charset="utf-8">
<?php
	include "dbpass.php";

	$id = $_POST['id'];

	session_start();
	unset($_SESSION["userid"]); // 로그아웃 unset 변수값 제거

	$sql = "delete from member where id='$id'";
	// member 테이블에서 id값이 일치하는 레코드 삭제

	$result = $dbConnect->query($sql); // 데이터베이스 실행
?>
<script>
	alert('회원탈퇴가 완료되었습니다');
	location.href = 'index.php';
</script>