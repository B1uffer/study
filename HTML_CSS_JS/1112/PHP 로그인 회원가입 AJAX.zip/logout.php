<?php
	session_start();
	unset($_SESSION["userid"]); // unset 변수값 제거
?>
<script>
	location.href = 'index.php';
</script>