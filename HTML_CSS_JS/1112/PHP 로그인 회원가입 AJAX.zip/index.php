<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>수업용</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="https://code.jquery.com/jquery-3.6.4.js"></script>
	
	<style>
		*{margin: 0; padding: 0;}
		li{list-style: none;}
		em, i, address{font-style: normal;}
		a{text-decoration: none; color: inherit;}
		
		@media all and (max-width:768px){
			
		}
	</style>
</head>

<body>
	
	<?php
		session_start(); // 로그인_insert 손님 브라우저에 임시 저장된 변수값을 불러옴
		if(isset($_SESSION["userid"])){ // isset 변수에 값이 있으면 true
	?>
		<a href="logout.php">로그아웃</a><!--로그인 적용-->
		<a href="modify.php">회원정보수정</a>
	<?php
		} else {
	?>
		<a href="login.php">로그인</a><!--로그인 미적용-->
		<a href="member.php">회원가입</a>
	<?php
		}
	?>
	
	
	<script>

		
		
	</script>
	
</body>
	
</html>
