<?php
	include "dbpass.php";

	$id = $_POST['a'];

	$sql = "select * from member where id='$id'";
	$result = $dbConnect->query($sql);

	$num_record = mysqli_num_rows($result);

	if ($num_record == 1){
		echo $id." 아이디는 중복입니다.";
	}
?>
