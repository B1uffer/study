<meta charset="utf-8">
<?php
	include "dbpass.php";

	$id = $_POST["id"];
	$pw = $_POST["pw"];

	$sql = "select * from member where id='$id'"; // member테이블의 모든 필드를 조회하겠다 (단 손님이 입력한 id와 해당 테이블에 존재하는 id 같은 값만 조회)
	$result = $dbConnect->query($sql);	// 데이터베이스 실행

	$count = mysqli_num_rows($result); // 조회된 레코드 개수
	$row = mysqli_fetch_array($result); // 선택된 레코드의 값을 배열로 가져옴

	if($count <= 0){
?>
		<script>
			alert('존재하지 않는 아이디입니다!');
			location.href = 'login.php';
		</script>
<?php
	} else if($pw != $row["pw"]) {
?>
		<script>
			alert('비밀번호가 틀립니다!');
			location.href = 'login.php';
		</script>
<?php
	} else {
		session_start();
		$_SESSION["userid"] = $id; // 손님이 입력한 id값을 손님의 브라우저에 userid라는 변수명으로 임시 저장함
?>
		<script>
			location.href = 'index.php';
		</script>
<?php
	}      
?>
