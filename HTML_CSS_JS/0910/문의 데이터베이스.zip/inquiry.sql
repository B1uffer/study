create table inquiry(
    num int not null auto_increment comment '기본키(식별자) 필드',
    name text not null,
    phone text not null,
    content text not null,
    primary key(num)
);
