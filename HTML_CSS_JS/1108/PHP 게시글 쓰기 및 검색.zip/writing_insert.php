<meta charset="utf-8">
<?php
	$host = "localhost";
    $user = "";   // 닷홈 데이터베이스 아이디 입력
	$pw = "";     // 닷홈 데이터베이스 비밀번호 입력
	$dbName = "";         // 닷홈 데이터베이스 이름 입력
    $dbConnect = new mysqli($host, $user, $pw, $dbName);
    $dbConnect->set_charset("utf8");
	
    $title = $_POST['title'];
    $content = $_POST['content'];
    $regist_day = date('Y-m-d (H:i:s)');

    $sql = "insert into writing(title, content, regist_day) values('$title', '$content', '$regist_day')";	// writing테이블에 새 레코드를 추가
    $result = $dbConnect->query($sql);	// 데이터베이스 실행

	echo "<script> alert('게시글 작성 완료'); location.href = 'writing_form.php'; </script>";
?>