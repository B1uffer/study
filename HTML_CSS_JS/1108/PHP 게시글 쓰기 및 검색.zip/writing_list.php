<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>무제 문서</title>
</head>

<body>
	<?php
		$host = "localhost";
		$user = "";   // 닷홈 데이터베이스 아이디 입력
		$pw = "";     // 닷홈 데이터베이스 비밀번호 입력
		$dbName = "";         // 닷홈 데이터베이스 이름 입력
		$dbConnect = new mysqli($host, $user, $pw, $dbName);
		$dbConnect->set_charset("utf8");
	
		if(isset($_GET['keyword'])){	// 검색값이 있다면 true 검색값이 없으면 false
			$keyword = $_GET['keyword'];
			$sql = "select * from writing where title like '%{$keyword}%' order by num desc";	// writing테이블에 있는 모든 레코드를 조회 (*는 모든 필드 조회한다는 뜻), title필드에서 손님이 입력한 검색 키워드랑 같은 것만 조회, num필드를 기준으로 내림차순
		} else {
			$sql = "select * from writing order by num desc";
		}
	
    	$result = $dbConnect->query($sql);	// 데이터베이스 실행
		$count = mysqli_num_rows($result);	// 레코드 총 개수
	
		echo '<ul>';
	
		for($i = 0; $i < $count; $i++){
			mysqli_data_seek($result, $i);	// 전체 레코드 중에서 i변수값에 맞게 해당 레코드를 선택
			$cys = mysqli_fetch_array($result);	//	선택된 레코드를 조회해서 해당 변수에 배열로 넣음
		?>
	<li><a href="writing_view.php?num=<?=$cys['num']?>"><?=$cys['title']?></a><?=$cys['regist_day']?></li>
	<?php
		}
	
		echo '</ul>';
	?>
	
	<script>
		
	</script>
</body>
</html>
