<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>무제 문서</title>
</head>

<body>
	<?php
		$host = "localhost";
		$user = "";   // 닷홈 데이터베이스 아이디 입력
		$pw = "";     // 닷홈 데이터베이스 비밀번호 입력
		$dbName = "";         // 닷홈 데이터베이스 이름 입력
		$dbConnect = new mysqli($host, $user, $pw, $dbName);
		$dbConnect->set_charset("utf8");
		
		$num = $_GET['num'];
	
		$sql = "select * from writing where num=$num";	// writing테이블에 있는 모든 레코드를 조회 (*는 모든 필드를 조회한다는 뜻)
		// num필드 중에서 num변수값이랑 같은 것만 조회
    	$result = $dbConnect->query($sql);	// 데이터베이스 실행
		$cys = mysqli_fetch_array($result);		//	선택된 레코드를 조회해서 해당 변수에 배열로 넣음
		
		echo $cys['title'] . $cys['content'] . $cys['regist_day'];
	?>
</body>
</html>
