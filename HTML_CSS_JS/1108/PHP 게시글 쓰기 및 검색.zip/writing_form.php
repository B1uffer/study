<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>최용수 수업용</title>
	<script src="https://code.jquery.com/jquery-3.0.0.js"></script>
	
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>

	<form method="post" action="writing_insert.php">

		<input type="text" name="title" placeholder="게시글 제목">
		<textarea name="content"></textarea>
		<input type="submit" value="글쓰기">

	</form>
	
	<form method="get" action="writing_list.php">
		<input type="text" name="keyword" placeholder="게시글 검색">
		<input type="submit" value="검색">
	</form>
	
	<a href="writing_list.php">게시글 전체 보기</a>

</body>
</html>
